# Garnet Helm Chart

This Helm chart deploys the Garnet agent to Kubernetes clusters, providing runtime security for your workloads.

## Prerequisites

- Kubernetes 1.16+
- Helm 3.0+
- A valid Garnet API token (required for standard mode, not required for standalone mode)

## Installation

### Option 1: Garnet (with API integration)

#### From Helm Repository

```bash
# Add the Garnet Helm repository
helm repo add garnet https://helm.garnet.ai
helm repo update

# Install Garnet with API integration
helm install garnet garnet/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN
```

#### From Local Sources

```bash
# Install Garnet with API integration
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN
```

### Option 2: Jibril Standalone (no Garnet API)

#### From Helm Repository

```bash
# Add the Garnet Helm repository
helm repo add garnet https://helm.garnet.ai
helm repo update

# Install Jibril standalone
helm install jibril garnet/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true

# Install Jibril with specific version
helm install jibril garnet/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true \
  --set standalone.jibrilVersion=v2.2.1
```

#### From Local Sources

```bash
# Install Jibril standalone
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true

# Install Jibril with specific version
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true \
  --set standalone.jibrilVersion=v2.2.1
```

## Configuration

The following table lists the configurable parameters of the Garnet chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `namespace` | **REMOVED** - Now specified using Helm's `--namespace` flag | N/A |
| `standalone.enabled` | Enable standalone mode (Jibril only, no Garnet API) | `false` |
| `standalone.jibrilVersion` | Override Jibril version in standalone mode | `""` |
| `garnet.url` | Garnet API URL | `https://api.garnet.ai` |
| `garnet.token` | Your Garnet API token (required in standard mode) | `""` |
| `cluster.name` | Name of the cluster | `garnet-cluster` |
| `image.registry` | Global registry for all images | `""` |
| `image.tag` | Global tag for all images | `latest` |
| `image.pullPolicy` | Global pull policy for all images | `Always` |
| `image.pullSecrets` | Global pull secrets for all images | `[]` |
| `jibril.image.registry` | Overrides global registry for Jibril image | `""` |
| `jibril.image.repository` | Repository for Jibril image | `garnetlabs/jibril` |
| `jibril.image.tag` | Overrides global tag for Jibril image | `v2.4` |
| `jibril.image.pullPolicy` | Overrides global pull policy for Jibril image | `""` |
| `jibrilInit.enabled` | Enable Jibril init container | `true` |
| `jibrilHeartbeat.enabled` | Enable Jibril heartbeat container | `true` |
| `policyRefresher.enabled` | Enable policy refresher container | `true` |
| `policyRefresher.config.refreshInterval` | How often to refresh policies | `30s` |
| `policyRefresher.config.logLevel` | Log level for policy refresher | `INFO` |

For a complete list of configuration options, please see the [values.yaml](values.yaml) file.

## Environment Variables

The chart supports two methods for setting custom environment variables for the Jibril container:

### Method 1: Simple Environment Variables (via --set)

Use the `jibril.env` object for simple key-value pairs that can be easily set via `helm install` or `helm upgrade`:

```bash
# Set environment variables via command line
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  --set jibril.env.CUSTOM_VAR=myvalue \
  --set jibril.env.ANOTHER_VAR=anothervalue \
  --set jibril.env.DEBUG_MODE=true
```

Or in a values file:

```yaml
jibril:
  env:
    CUSTOM_VAR: "myvalue"
    ANOTHER_VAR: "anothervalue"
    DEBUG_MODE: "true"
```

### Method 2: Complex Environment Variables (with valueFrom)

Use the `jibril.customEnv` array for more complex environment variables that need to reference secrets or configmaps:

```yaml
jibril:
  customEnv:
    - name: MY_CUSTOM_VAR
      value: "my-value"
    - name: MY_SECRET_VAR
      valueFrom:
        secretKeyRef:
          name: my-secret
          key: secret-key
    - name: MY_CONFIGMAP_VAR
      valueFrom:
        configMapKeyRef:
          name: my-configmap
          key: config-key
```

### Combining Both Methods

Both methods can be used together. The simple `env` method is processed after `customEnv`, so values in `env` will override any duplicates in `customEnv`:

```bash
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  --set jibril.env.API_ENDPOINT=https://api.example.com \
  --set jibril.env.LOG_LEVEL=debug \
  -f custom-env-values.yaml
```

Where `custom-env-values.yaml` contains:

```yaml
jibril:
  customEnv:
    - name: DB_PASSWORD
      valueFrom:
        secretKeyRef:
          name: db-credentials
          key: password
```

## Network Policy Support

The chart supports deploying Jibril with custom network policies. This is particularly useful in standalone mode when you want to enable network policy enforcement.

### Enabling Network Policy

You can provide a network policy file using `--set-file`:

```bash
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true \
  --set networkPolicyConfig.enabled=true \
  --set-file networkPolicyConfig.policyYaml=./my-network-policy.yaml
```

### Complete Example with Custom Config and Network Policy

Deploy Jibril standalone with custom configuration, network policy, and environment variables:

```bash
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true \
  --set jibrilConfig.customConfig=true \
  --set-file jibrilConfig.configYaml=./my-jibril-config.yaml \
  --set networkPolicyConfig.enabled=true \
  --set-file networkPolicyConfig.policyYaml=./my-network-policy.yaml \
  --set jibril.env.AI_URL="https://api.example.com" \
  --set jibril.env.AI_TOKEN="your-token-here"
```

**Important**: When using network policy, ensure your custom Jibril config includes:
```yaml
features:
  - netpolicy
  - detect

feature_options:
  netpolicy:
    file: /etc/jibril/network-policy.yaml

events:
  - dropip
  # You can also add dropdomain if needed
```

The network policy file will be automatically mounted at `/etc/jibril/network-policy.yaml`.

### Network Policy Demo: Install and Update

This example demonstrates installing Jibril with a network policy and then updating it:

#### 1. Initial Installation

Create a simple network policy file `netpolicy.yaml`:
```yaml
network_policy:
  mode: "both"       # Options: bypass, alert, enforce, both
  policy: "deny"     # Default policy: allow or deny
  allow:
    - "127.0.0.0/8"
    - "10.0.0.0/8"
  deny: []
  resolve:
    - "example.com"  # Domains to resolve and block if they match deny rules
```

Install Jibril with the network policy:
```bash
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true \
  --set standalone.jibrilVersion=v2.2.2 \
  --set jibrilConfig.customConfig=true \
  --set-file jibrilConfig.configYaml=./config-5.10-attenuator.yaml \
  --set networkPolicyConfig.enabled=true \
  --set-file networkPolicyConfig.policyYaml=./netpolicy.yaml \
  --set jibril.env.AI_URL="https://your-ai-api.com" \
  --set jibril.env.AI_TOKEN="your-ai-token"
```

#### 2. Test the Network Policy

```bash
# Test that example.com is blocked
kubectl run test-curl --image=curlimages/curl --namespace security --rm --restart=Never -- curl -I --max-time 5 http://example.com

# Test that other domains work
kubectl run test-curl --image=curlimages/curl --namespace security --rm --restart=Never -- curl -I http://google.com
```

#### 3. Update the Network Policy

Create an updated policy file `netpolicy-updated.yaml`:
```yaml
network_policy:
  mode: "both"
  policy: "deny"
  allow:
    - "127.0.0.0/8"
    - "10.0.0.0/8"
  deny:
    - "1.2.3.4/32"
  resolve:
    - "example.com"
    - "badsite.com"
```

Update the deployment:
```bash
helm upgrade jibril ./helm/garnet \
  --namespace security \
  --set standalone.enabled=true \
  --set standalone.jibrilVersion=v2.2.2 \
  --set jibrilConfig.customConfig=true \
  --set-file jibrilConfig.configYaml=./config-5.10-attenuator.yaml \
  --set networkPolicyConfig.enabled=true \
  --set-file networkPolicyConfig.policyYaml=./netpolicy-updated.yaml \
  --set jibril.env.AI_URL="https://your-ai-api.com" \
  --set jibril.env.AI_TOKEN="your-ai-token"
```

**Note**: The pods will automatically restart due to the checksum annotations, ensuring they pick up the new network policy.

#### 4. Verify the Update

```bash
# Check that pods restarted
kubectl get pods -n security -w

# Verify new policy is in place
kubectl exec -n security daemonset/jibril -- cat /etc/jibril/network-policy.yaml

# Test the new blocks
kubectl run test-curl-1 --image=curlimages/curl --namespace security --rm --restart=Never -- curl -I --max-time 5 http://badsite.com
kubectl run test-curl-2 --image=curlimages/curl --namespace security --rm --restart=Never -- curl -I --max-time 5 http://1.2.3.4
```

## Customizing Jibril Configuration

You can customize the Jibril configuration in two ways (works in both standard and standalone modes):

1. **Override specific config values** - Modify individual settings using Helm values:

```bash
helm install garnet ./helm/garnet \
  --namespace garnet-system \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  --set jibril.config.logLevel=debug \
  --set jibril.config.profiler=true
```

1. **Provide a complete custom configuration** - Supply your own full config.yaml:

Create a file named `custom-values.yaml`:

```yaml
jibrilConfig:
  customConfig: true
  configYaml: |
    # Custom Jibril Configuration
    run-time:
      log-level: debug
      stdout: stdout
      stderr: stderr
      health: true
      profiler: true
      cardinal: true
      metrics: false

    cadences:
      file-access: 3
      network-peers: 3
      network-flows: 3
      env-vars: 3

    caches:
      rec-tasks: 32
      tasks: 64
      cmds: 32
      args: 32
      files: 32
      dirs: 16
      bases: 32
      task-file: 32
      file-task: 32
      task-ref: 32
      flows: 32
      task-flow: 32
      flow-task: 32
      flow-ref: 32

    functionalities:
      - jibril

    features:
      - hold
      - procfs
      - netpolicy
      - detect

    feature_options:
      netpolicy:
        file: /etc/jibril/network-policy.yaml
      detect:

    printers:
      - stdout
      - varlog
      - garnet

    printer_options:
      stdout:
        raw: false
      varlog:
        raw: true
        file: /var/log/jibril.out
      garnet:
        error_log_rate: 2m

    events:
      # Network Policy
      - dropip
      # Add your custom detection events here
      - code_on_the_fly
      - interpreter_shell_spawn
      - webserver_exec
      - hidden_elf_exec

    event_options:
```

Then install with:

```bash
helm install garnet ./helm/garnet \
  --namespace garnet-system \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  -f custom-values.yaml
```

## Standalone Mode Details

When `standalone.enabled=true` is set:
- **No Garnet API token required** - The chart skips token validation
- **Automatic component disabling** - `jibrilInit`, `jibrilHeartbeat`, and `policyRefresher` are automatically disabled
- **Minimal configuration** - The default config excludes Garnet-specific plugins and printers
- **Custom version support** - Use `standalone.jibrilVersion` to specify a particular Jibril version for old kernel compatibility

The standalone configuration removes:
- Garnet printer from the `printers` list
- Network policy feature is retained in standalone mode for custom network policy enforcement
- Garnet-specific integration (jibrilInit, jibrilHeartbeat, policyRefresher containers)

## Examples

### Basic Installation

```bash
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN
```

### Jibril Standalone Mode

```bash
# Basic standalone deployment
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true

# Standalone with custom Jibril version
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true \
  --set standalone.jibrilVersion=v2.2.1

# Standalone with custom configuration
helm install jibril ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set standalone.enabled=true \
  --set jibrilConfig.customConfig=true \
  --set-file jibrilConfig.configYaml=my-jibril-config.yaml
```

### Custom Container Registry

```bash
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  --set image.registry=my-registry.example.com/
```

### Specific Image Tags

```bash
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  --set image.tag=v2.0 \
  --set jibril.image.tag=v2.1
```

### Custom Resource Settings

```bash
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  --set policyRefresher.config.refreshInterval=60s \
  --set policyRefresher.config.logLevel=DEBUG \
  --set jibril.resources.requests.memory=512Mi
```

### With Image Pull Secrets

```bash
helm install garnet ./helm/garnet \
  --namespace security \
  --create-namespace \
  --set garnet.token=YOUR_GARNET_API_TOKEN \
  --set image.registry=my-private-registry.example.com/ \
  --set image.pullSecrets[0]=my-registry-secret
```

## Support

For more information, visit: <https://garnet.ai>

## Testing the Chart

The chart includes tests to verify proper deployment. After installing the chart, run:

```bash
helm test garnet -n your-namespace
```

This will run tests to verify:

- DaemonSet creation
- ConfigMap creation
- Secret creation
