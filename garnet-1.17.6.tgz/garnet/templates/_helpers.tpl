{{/*
Expand the name of the chart.
*/}}
{{- define "garnet.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "garnet.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "garnet.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "garnet.labels" -}}
helm.sh/chart: {{ include "garnet.chart" . }}
{{ include "garnet.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "garnet.selectorLabels" -}}
app.kubernetes.io/name: {{ include "garnet.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Validate garnet.token is set
*/}}
{{- define "garnet.validateApiToken" -}}
{{- if not .Values.garnet.token -}}
{{- fail "garnet.token is required and must not be empty" -}}
{{- end -}}
{{- end -}}

{{/*
Return the proper image name
*/}}
{{- define "garnet.getImage" -}}
{{- $registryName := .registry -}}
{{- $repositoryName := .repository -}}
{{- $tag := .tag | toString -}}

{{- if .global }}
    {{- if .global.registry }}
        {{- $registryName = .global.registry -}}
    {{- end -}}
    {{- if and (not $tag) .global.tag }}
        {{- $tag = .global.tag | toString -}}
    {{- end -}}
{{- end -}}

{{- if $registryName }}
    {{- $registryName = trimSuffix "/" $registryName -}}
    {{- printf "%s/%s" $registryName $repositoryName -}}
{{- else -}}
    {{- $repositoryName -}}
{{- end -}}

{{- if $tag }}
    {{- printf ":%s" $tag -}}
{{- end -}}
{{- end -}}

{{/*
Return the proper Docker Image Registry Secret Names
*/}}
{{- define "garnet.imagePullSecrets" -}}
{{- if .Values.image.pullSecrets }}
imagePullSecrets:
{{- range .Values.image.pullSecrets }}
  - name: {{ . }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Return the proper image pull policy
*/}}
{{- define "garnet.imagePullPolicy" -}}
{{- $pullPolicy := .pullPolicy -}}

{{- if .global }}
    {{- if and (not $pullPolicy) .global.pullPolicy }}
        {{- $pullPolicy = .global.pullPolicy -}}
    {{- end -}}
{{- end -}}

{{- if $pullPolicy }}
    {{- $pullPolicy -}}
{{- else -}}
    {{- "IfNotPresent" -}}
{{- end -}}
{{- end -}}

{{/*
Return memory resource with fallback to global default
*/}}
{{- define "garnet.memory" -}}
{{- $component := .component -}}
{{- $memory := .memory -}}
{{- $type := .type | default "" -}}
{{- if $memory }}
    {{- $memory -}}
{{- else if .global }}
    {{- $memoryConfig := index .global.resources.memory $component -}}
    {{- if kindIs "map" $memoryConfig }}
        {{- if $type }}
            {{- index $memoryConfig $type -}}
        {{- else }}
            {{- $memoryConfig.limits | default $memoryConfig -}}
        {{- end -}}
    {{- else }}
        {{- $memoryConfig -}}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Return CPU resource with fallback to global default
*/}}
{{- define "garnet.cpu" -}}
{{- $component := .component -}}
{{- $cpu := .cpu -}}
{{- $type := .type -}}
{{- if $cpu }}
    {{- $cpu -}}
{{- else if .global }}
    {{- index .global.resources.cpu $component $type -}}
{{- end -}}
{{- end -}}